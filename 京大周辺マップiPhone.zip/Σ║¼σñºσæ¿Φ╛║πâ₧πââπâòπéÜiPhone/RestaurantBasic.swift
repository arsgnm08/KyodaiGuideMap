//
//  RestaurantBasic.swift
//  京大周辺マップiPhone
//
//  Created by 丸谷 浩永 on 8/27/16.
//  Copyright © 2016 丸谷 浩永. All rights reserved.
//

import Foundation
import CoreData


class RestaurantBasic: NSManagedObject {
    
// Insert code here to add functionality to your managed object subclass

}
