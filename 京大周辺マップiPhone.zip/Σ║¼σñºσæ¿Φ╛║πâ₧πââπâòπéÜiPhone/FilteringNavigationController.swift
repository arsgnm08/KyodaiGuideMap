//
//  FilteringNavigationController.swift
//  KyodaiGuideMapApp
//
//  Created by 丸谷 浩永 on 9/22/16.
//  Copyright © 2016 丸谷 浩永. All rights reserved.
//

import UIKit

class FilteringNavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        addButtons()
    }
    
    fileprivate func addButtons() {
        setupSearchBar()
        self.viewControllers.first!.navigationItem.leftBarButtonItem = UIBarButtonItem(title:"フィルタ", style:UIBarButtonItemStyle.plain, target: self, action: #selector(FilteringNavigationController.setupCriteria))
    }
    
    fileprivate func setupSearchBar() {
        let navigationBarFrame = self.navigationBar.bounds
        let searchBar: UISearchBar = UISearchBar(frame: navigationBarFrame)
        searchBar.delegate = self
        searchBar.placeholder = "Search"
        searchBar.autocapitalizationType = UITextAutocapitalizationType.none
        searchBar.keyboardType = UIKeyboardType.default
        self.viewControllers.first!.navigationItem.titleView = searchBar
        //searchBar.showsCancelButton = true
        self.viewControllers.first!.navigationItem.titleView?.frame = searchBar.frame
        let viewController = self.viewControllers.first as! ResultViewController
        viewController.searchBar = searchBar
        //searchBar.becomeFirstResponder()
    }
    
    //MARK: configure bar buttons
    
    @objc fileprivate func setupCriteria() {
        //configure popover view
        
        let presentingViewController = self.topViewController as! ResultViewController
        let viewController = presentingViewController.viewController
        viewController.modalPresentationStyle = .popover
        viewController.preferredContentSize = presentingViewController.viewController.view.frame.size
        viewController.previousViewController = self
        
        if let presentationController = presentingViewController.viewController.popoverPresentationController {
            presentationController.permittedArrowDirections = .up
            presentationController.barButtonItem = self.topViewController!.navigationItem.leftBarButtonItem
            presentationController.delegate = self
        }
        present(presentingViewController.viewController, animated: true, completion: nil)
    }
    
    @objc fileprivate func dismissKeyboard() {
        self.view.endEditing(true)
        let viewController = self.topViewController as! ResultViewController
        let tabBarController = self.tabBarController as! TabBarController
        if let text : NSString = viewController.searchBar.text as NSString? {
            if text.length < 1 {
                viewController.searchBar.text = ""
                tabBarController.criteria.keyWord = ""
                tabBarController.changedCriteria = true
            }
        }
        viewController.reloadFetchedData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

//MARK: UISearchBarDelegate Methods

extension FilteringNavigationController : UISearchBarDelegate {
    
    //Search Bar に文字入力を開始する際に、タップによるキャンセル操作を定義
    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {
        let tap = UITapGestureRecognizer(target: self, action: #selector(FilteringNavigationController.dismissKeyboard))
        self.view.addGestureRecognizer(tap)
        return true
    }
    
    //キャンセルボタンをタップした際の動作（現在使っていない）
    /*
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchBar.text = ""
        
        let tabBarController = self.tabBarController as! TabBarController
        tabBarController.criteria.keyWord = searchBar.text!
        tabBarController.changedCriteria = true
        
        let viewController = self.viewControllers.first as! ResultViewController
        viewController.reloadFetchedData()
        searchBar.resignFirstResponder()
    }
    */
 
    //検索を実行するボタンをタップした際の動作
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        let tabBarController = self.tabBarController as! TabBarController
        tabBarController.criteria.keyWord = searchBar.text!
        tabBarController.changedCriteria = true
        let viewController = self.viewControllers.first as! ResultViewController
        viewController.reloadFetchedData()
        viewController.searchBar.resignFirstResponder()
    }

}

//MARK: ModalViewControllerDelegate Methods

extension FilteringNavigationController : ModalViewControllerDelegate {
    
    func modalDidFinished() {
        let presentingViewController = self.viewControllers.first as! ResultViewController
        let viewController = presentingViewController.viewController
        viewController.dismiss(animated: true, completion: nil)
        if viewController.changed > 0 {
            let tabBarController = self.tabBarController as! TabBarController
            tabBarController.changedCriteria = true
            presentingViewController.reloadFetchedData()
        }
    }
    
    func modalResetTapped() {
        let presentingViewController = self.viewControllers.first as! ResultViewController
        let tabBarController = self.tabBarController as! TabBarController
        tabBarController.clearCriteria()
        tabBarController.changedCriteria = true
        presentingViewController.searchBar.text = ""
        presentingViewController.reloadFetchedData()
        presentingViewController.viewController.dismiss(animated: true, completion: nil)
    }
}

extension FilteringNavigationController : UIPopoverPresentationControllerDelegate{
    
    func adaptivePresentationStyle(for controller: UIPresentationController) -> UIModalPresentationStyle {
        return .none
    }
    
}
