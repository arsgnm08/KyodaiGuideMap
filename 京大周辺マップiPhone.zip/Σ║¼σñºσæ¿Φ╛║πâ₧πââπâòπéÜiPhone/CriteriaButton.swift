//
//  criteriaButton.swift
//  京大周辺マップiPhone
//
//  Created by 丸谷 浩永 on 8/26/16.
//  Copyright © 2016 丸谷 浩永. All rights reserved.
//

import UIKit

class criteriaButton: UIButton {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
