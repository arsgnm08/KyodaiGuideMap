//
//  MasterViewController.swift
//  京大周辺マップiPhone
//
//  Created by 丸谷 浩永 on 8/1/16.
//  Copyright (c) 2016 丸谷 浩永. All rights reserved.
//

import UIKit
import CoreData
import CoreLocation
import MapKit

class MasterViewController: UITableViewController {

    var managedObjectContext: NSManagedObjectContext? = nil
    var fetchRequest : NSFetchRequest<RestaurantBasic>? = nil
    var fetchedResultsController : NSFetchedResultsController<RestaurantBasic> {
        let tabBarController = self.tabBarController as? TabBarController
        return (tabBarController?.fetchedResultsController)!
    }
    var fetchedResultsArray : NSArray? = nil
    var searchBar: UISearchBar = UISearchBar()
    var criteria : Criteria! = nil
    
    let viewController : PopoverCriteriaViewController = PopoverCriteriaViewController(nibName: "PopoverCriteriaViewController", bundle: nil)
    
    var locationManager : CLLocationManager? = nil
    var appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate //AppDelegateのインスタンスを取得
//    var latitude : CLLocationDegrees = 35.022487
//    var longitude : CLLocationDegrees = 135.779858

    //MARK: Internal Functions
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tabBarController = self.tabBarController as? TabBarController
        tabBarController?.changedCriteria = true
        fetchedResultsArray = fetchedResultsController.fetchedObjects as NSArray?
        
        //現在地取得開始
        if CLLocationManager.locationServicesEnabled() {
        
            //configure locationManager
            locationManager = CLLocationManager()
            locationManager?.delegate = self
            locationManager?.requestAlwaysAuthorization()
            locationManager?.delegate = self
            locationManager?.desiredAccuracy = kCLLocationAccuracyBest
            locationManager?.distanceFilter = 50
            locationManager?.requestLocation()
//            locationManager?.startUpdatingLocation()
        }else {
            appDelegate.lon = 135.779858
            appDelegate.lat = 35.022487
        }
        if appDelegate.lon == 0.0 {             //初期値から更新されていない場合、強制的に代入
            appDelegate.lon = 135.779858
        }
        if appDelegate.lat == 0.0 {
            appDelegate.lat = 35.022487
        }
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        //ビューを再表示する際にはデータをデータベースから改めて読み込む
        super.viewWillAppear(true)
        let tabBarController = self.tabBarController as? TabBarController
        tabBarController?.changedCriteria = true
        reloadFetchedData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Segues

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //詳細のビューに飛ぶ際の処理
        if segue.identifier == "showDetail" {
            if let indexPath = self.tableView.indexPathForSelectedRow {
            let object = self.fetchedResultsController.object(at: indexPath)
                (segue.destination as! DetailViewController).restaurantBasicInfo = object
                segue.destination.hidesBottomBarWhenPushed = true
            }
        }
    }

    // MARK: - Table View

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (self.fetchedResultsArray?.count)!
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)  as? TableViewCell
        self.configureCell(cell!, atIndexPath: indexPath)
        return cell!
    }

    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return false
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "showDetail", sender: self)
    }
    
    fileprivate func configureCell(_ cell: TableViewCell, atIndexPath indexPath: IndexPath) {
        //Table View のセルを設定
        let object = self.fetchedResultsArray!.object(at: (indexPath as NSIndexPath).row) as! RestaurantBasic
        cell.basicInformation = object
        let label = cell.viewWithTag(2) as? UILabel
        label!.text = calculateTime((Double(object.longitude!)!, Double(object.latitude!)!))
    }
 
}

//MARK: CLLocationManagerDelegate methods

extension MasterViewController : CLLocationManagerDelegate {
    
    //現在位置が更新された際に呼び出し
    @objc(locationManager:didUpdateLocations:)
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        appDelegate.lon = locations[locations.count-1].coordinate.longitude
        appDelegate.lat = locations[locations.count-1].coordinate.latitude
        
        self.tableView.reloadData()
    }
    
    //現在位置の読み込みに失敗した際に呼び出し
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        appDelegate.lon = 135.779858    // ここで位置情報決定
        appDelegate.lat = 35.022487
        NSLog("Error")
        self.tableView.reloadData()
    }
    
    //位置情報利用の権限について変更があった場合
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .notDetermined:
            manager.requestWhenInUseAuthorization()
        case .restricted, .denied:
            break
        case .authorizedAlways, .authorizedWhenInUse:
            break
        }
    }

}

//MARK: ResultViewController methods

extension MasterViewController : ResultViewController {
    
    //データの再読み込み
    func reloadFetchedData() {
        fetchedResultsArray = fetchedResultsController.fetchedObjects as NSArray?
        self.tableView.reloadData()
    }
}

//MARK: TableViewCellDelegate methods

extension MasterViewController : TableViewCellDelegate {
    
    //所用時間を計算
    func calculateTime(_ coordinate : (longitude : Double, latitude : Double)) -> String{
        
        let currentLocation = CLLocationCoordinate2DMake(appDelegate.lon, appDelegate.lat)
        let destinationLocation = CLLocationCoordinate2DMake(coordinate.longitude, coordinate.latitude)
        let source : MKMapItem = MKMapItem(placemark: MKPlacemark(coordinate: currentLocation, addressDictionary: nil))
        let destination : MKMapItem = MKMapItem(placemark: MKPlacemark(coordinate: destinationLocation, addressDictionary: nil))
        
        let request : MKDirectionsRequest = MKDirectionsRequest()
        request.source = source
        request.destination = destination
        //request.requestsAlternateRoutes = false
        //request.transportType = MKDirectionsTransportType.Walking
        
        var expectedTime : String? = ""
        let direction = MKDirections(request: request)
        
        
        direction.calculateETA(completionHandler: {
            (response, error) in
            
            if error == nil {
                expectedTime = response?.expectedTravelTime.description
                NSLog(expectedTime!)
            }else {
                NSLog((error?.localizedDescription)!)
            }
            
        })
        
        return expectedTime!
    }

}
