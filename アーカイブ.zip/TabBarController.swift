//
//  TabBarController.swift
//  
//
//  Created by 丸谷 浩永 on 8/22/16.
//
//

import UIKit

class TabBarController: UITabBarController {
   
}
